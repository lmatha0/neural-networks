#import libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#load and display dataset (https://www.kaggle.com/datasets/gallo33henrique/bioinformatics-protein-dataset-simulated/data)
df = pd.read_csv('protein_dataset.csv')
print(df.head(10)) 

#one hot encode 'Class'
Y = df['Class']
categories, inverse = np.unique(Y, return_inverse=True)
Y_one_hot = np.zeros((Y.size, categories.size))
Y_one_hot[np.arange(Y.size), inverse] = 1

#define input and output labels
X = df.drop(columns=['ID', 'Sequence', 'Class']).values
Y = Y_one_hot

#normalize features
X_norm = (X - X.mean(axis=0)) / X.std(axis=0)

#split dataset into train/test sets
np.random.seed(42)
idx = np.arange(X_norm.shape[0])
split = int(0.8 * len(idx))
train_idx, test_idx = idx[:split], idx[split:]

X_train, X_test = X_norm[train_idx], X_norm[test_idx]
Y_train, Y_test = Y[train_idx], Y[test_idx]

#initialize parameters with He initialization 
def init_param(layers):
    np.random.seed(42)
    parameters = {}
    L = len(layers)
    for i in range(1, L):
        parameters["W" + str(i)] = np.random.randn(layers[i], layers[i-1]) * np.sqrt(2 / layers[i-1])
        parameters["b" + str(i)] = np.zeros((layers[i], 1))
    return parameters

#define forward propagation
def linear(A, W, b):
    Z = np.dot(W, A) + b
    cache = (A, W, b)
    return Z, cache

def relu(Z):
    return np.maximum(0, Z)

def softmax(Z):
    expZ = np.exp(Z - np.max(Z, axis=0, keepdims=True))
    return expZ / np.sum(expZ, axis=0, keepdims=True)

def forw_activ(A_prev, W, b, activation):
    Z, cache = linear(A_prev, W, b)
    if activation == "relu":
        A = relu(Z)
    elif activation == "softmax":
        A = softmax(Z)
    return A, (cache, Z)

def forward_prop(X, parameters):
    caches = [] #store A values in a cache
    A = X
    L = len(parameters) // 2

    for i in range(1, L):
        A, cache = forw_activ(A, parameters["W" + str(i)], parameters["b" + str(i)], "relu")
        caches.append(cache)

    AF, cache = forw_activ(A, parameters["W" + str(L)], parameters["b" + str(L)], "softmax")
    caches.append(cache)
    return AF, caches

#calculate cost
def cost(AF, Y):
    m = Y.shape[1]
    return -(1/m) * np.sum(Y * np.log(AF + 1e-8))

#define backward propagation
def linear_back(dZ, cache):
    A_prev, W, b = cache
    m = A_prev.shape[1]
    dW = (1/m) * np.dot(dZ, A_prev.T)
    db = (1/m) * np.sum(dZ, axis=1, keepdims=True)
    dA_prev = np.dot(W.T, dZ)
    return dW, db, dA_prev

def relu_back(Z):
    return (Z > 0).astype(float)

def back_activ(dA, for_cache, activation):
    cache, Z = for_cache
    if activation == "relu":
        dZ = dA * relu_back(Z)
    dW, db, dA_prev = linear_back(dZ, cache)
    return dA_prev, dW, db

def backward_prop(AF, Y, caches):
    grads = {}
    L = len(caches)

    #output layer
    current_cache = caches[L-1]
    dZ = AF - Y
    dW, db, dA_prev = linear_back(dZ, current_cache[0])
    grads["dW" + str(L)] = dW
    grads["db" + str(L)] = db

    #iterate through hidden layers
    for l in reversed(range(L-1)):
        current_cache = caches[l]
        dA_prev, dW, db = back_activ(dA_prev, current_cache, "relu")
        grads["dW" + str(l+1)] = dW
        grads["db" + str(l+1)] = db

    return grads

#update parameters
def update_param(parameters, grads, alpha):
    L = len(parameters) // 2
    for l in range(1, L+1):
        parameters["W" + str(l)] -= alpha * grads["dW" + str(l)]
        parameters["b" + str(l)] -= alpha * grads["db" + str(l)]
    return parameters

#train model
def train(X_train, Y_train, layers, alpha=0.05, iters=5000):
    parameters = init_param(layers)
    X_train = X_train.T
    Y_train = Y_train.T
    costs = [] #track costs over time

    for i in range(iters):
        AF, caches = forward_prop(X_train, parameters)
        c = cost(AF, Y_train)
        costs.append(c)
        grads = backward_prop(AF, Y_train, caches)
        parameters = update_param(parameters, grads, alpha)

        if i % 100 == 0:
            print(f"Iteration {i} | Cost: {c}")
    return parameters

#make a prediction for the model
def predict(X, parameters):
    AF, _ = forward_prop(X.T, parameters)
    return np.argmax(AF, axis=0)

layers = [X_train.shape[1], 128, 64, Y_train.shape[1]]
trained_params = train(X_train, Y_train, layers, alpha=0.05, iters=1000)

#compare to labeled data
predictions = predict(X_test, trained_params)
labels = np.argmax(Y_test, axis=1)
accuracy = np.mean(predictions == labels)
print(f"Test Accuracy: {accuracy}")
