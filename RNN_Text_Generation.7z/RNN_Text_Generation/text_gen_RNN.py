#import libraries
import numpy as np

#load text file
with open('rnn_text.txt', 'r', encoding='utf-8') as file:
    text = file.read().lower()
text = ''.join(c for c in text if c.isalpha() or c.isspace())

#sort vocabulary
list_text = sorted(set(text))
vocab_size = len(list_text)

#tokenize text to number and number to text
word2idx = {w: i for i, w in enumerate(list_text)}
idx2word = {i: w for i, w in enumerate(list_text)}
text_indices = [word2idx[c] for c in text]

#initialize weight and bias parameters
def init_param(hidden_size, vocab_size):
    W_xh = np.random.randn(hidden_size, vocab_size) * 0.01
    W_hh = np.random.randn(hidden_size, hidden_size) * 0.01
    W_hy = np.random.randn(vocab_size, hidden_size) * 0.01 #input and output size remain the same as text should retain same length
    b_h = np.zeros((hidden_size, 1))
    b_y = np.zeros((vocab_size, 1)) 
    
    param = (W_xh, W_hh, W_hy, b_h, b_y)
    return param

#one hot encode text
def one_hot(index, vocab_size):
    text_onehot = np.zeros((vocab_size, 1))
    text_onehot[index] = 1
    return text_onehot

#define softmax for word propability 
def softmax(logits):
    logits = logits - np.max(logits)  
    return np.exp(logits) / np.sum(np.exp(logits))

#calculate rnn for each cell
def rnn_forward_cell(Xt, h_prev, param):
    W_xh, W_hh, W_hy, b_h, b_y = param
    h_next = np.tanh(np.dot(W_hh, h_prev) + np.dot(W_xh, Xt) + b_h)
    y_pred = softmax(np.dot(W_hy, h_next) + b_y)
    
    forward_cell_cache = (Xt, h_prev, h_next, param)
    return h_next, y_pred, forward_cell_cache

#propagate rnn cell calculation to each cell
def rnn_forward_prop(Xt, h_prev, param):
    xs, hs, ys, cache = {}, {}, {}, {}
    hs[-1] = h_prev

    for t in range(len(Xt)):
        xs[t] = one_hot(Xt[t], vocab_size)
        hs[t], ys[t], cell_cache = rnn_forward_cell(xs[t], hs[t-1], param)
        cache[t] = cell_cache
    
    return xs, hs, ys, cache

#calculate rnn backprop per cell
def rnn_backward_cell(dh_next, cache):
    Xt, h_prev, h_next, (W_xh, W_hh, W_hy, b_h, b_y) = cache

    dtanh = (1 - h_next ** 2) * dh_next
    dW_xh = np.dot(dtanh, Xt.T)
    dW_hh = np.dot(dtanh, h_prev.T)
    db_h = np.sum(dtanh, axis=1, keepdims=True)
    dXt = np.dot(W_xh.T, dtanh)
    dh_prev = np.dot(W_hh.T, dtanh)

    gradients = {'dW_xh': dW_xh, 'dW_hh': dW_hh, 'db_h': db_h, 'dXt': dXt, 'dh_prev': dh_prev}
    return gradients

#propagate backprop over all cells
def rnn_backward_prop(xs, hs, ys, cache, y_true, vocab_size):
    _, _, _, param = cache[0]
    W_xh, W_hh, W_hy, b_h, b_y = param

    #initialize gradients, same shape as param
    dW_xh = np.zeros_like(W_xh)
    dW_hh = np.zeros_like(W_hh)
    dW_hy = np.zeros_like(W_hy)
    db_h  = np.zeros_like(b_h)
    db_y  = np.zeros_like(b_y)
    dh_next = np.zeros_like(hs[0])
    loss = 0

    for t in reversed(range(len(xs))):
        #one hot the true y label
        y_true_onehot = np.zeros((vocab_size, 1))
        y_true_onehot[y_true[t]] = 1

        #calculate output layer gradient
        dy = ys[t] - y_true_onehot
        loss += -np.log(ys[t][y_true[t], 0] + 1e-8)

        #calculate gradient for first hidden layer
        dW_hy += np.dot(dy, hs[t].T)
        db_y  += dy

        #backpropr over all cells
        dh = np.dot(W_hy.T, dy) + dh_next

        # Backprop through RNN cell
        grads = rnn_backward_cell(dh, cache[t])
        dW_xh += grads['dW_xh']
        dW_hh += grads['dW_hh']
        db_h  += grads['db_h']
        dh_next = grads['dh_prev']

    gradients = {'dW_xh': dW_xh, 'dW_hh': dW_hh, 'dW_hy': dW_hy, 'db_h': db_h, 'db_y': db_y}
    return gradients, loss, dh_next

def sample(param, id, length):
    W_xh, W_hh, W_hy, b_h, b_y = param
    h = np.zeros((W_hh.shape[0], 1))
    output = []
    for i in range(length):
        x = one_hot(id, vocab_size)
        h, y_pred, _ = rnn_forward_cell(x, h, param)
        id = np.random.choice(range(vocab_size), p=y_pred.ravel())
        output.append(idx2word[id])
    return ''.join(output)

def train(seq_length, hidden_size, alpha, iter):
    param = init_param(hidden_size, vocab_size)
    h_prev = np.zeros((hidden_size, 1))

    for i in range(iter):
        for j in range(0, len(text_indices) - seq_length, seq_length):
            X_sequence = text_indices[j:j + seq_length]
            Y_sequence = text_indices[j+1: j + seq_length + 1]
            
            xs, hs, ys, cache = rnn_forward_prop(X_sequence, h_prev, param)
            grads, loss, _ = rnn_backward_prop(xs, hs, ys, cache, Y_sequence, vocab_size)
            h_prev = hs[len(X_sequence)-1]
            
            for dparam in [grads['dW_xh'], grads['dW_hh'], grads['dW_hy'], grads['db_h'], grads['db_y']]:
                np.clip(dparam, -5, 5, out=dparam)

            W_xh, W_hh, W_hy, b_h, b_y = param
            W_xh -= alpha * grads['dW_xh']
            W_hh -= alpha * grads['dW_hh']
            W_hy -= alpha * grads['dW_hy']
            b_h  -= alpha * grads['db_h']
            b_y  -= alpha * grads['db_y']
            param = (W_xh, W_hh, W_hy, b_h, b_y)
        
        if i % 10 == 0:
            print(f"Iteration {i} | Loss: {loss}")
            sample_text = sample(param, text_indices[0], 50)
            print(f"Sample: {sample_text}")

    return param

hidden_size = 100
seq_length = 100
alpha = 0.001
iterations = 200

param = init_param(hidden_size, vocab_size)
trained_param = train(seq_length, hidden_size, alpha, iterations)




    







